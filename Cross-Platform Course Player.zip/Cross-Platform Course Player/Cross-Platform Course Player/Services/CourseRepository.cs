using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Text.Json;
using Cross_Platform_Course_Player.Models;

namespace Cross_Platform_Course_Player.Services;

public sealed class CourseRepository
{
    private readonly string _filePath;

    public ObservableCollection<Course> Courses { get; }

    public CourseRepository()
    {
        var dataDirectory = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "CrossPlatformCoursePlayer");
        _filePath = Path.Combine(dataDirectory, "courses.json");
        Courses = new ObservableCollection<Course>(LoadCourses());
    }

    public void AddCourse(Course course)
    {
        Courses.Add(course);

        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(_filePath)!);
            var json = JsonSerializer.Serialize(Courses, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(_filePath, json);
        }
        catch
        {
            Courses.Remove(course);
            throw;
        }
    }

    private List<Course> LoadCourses()
    {
        if (!File.Exists(_filePath))
        {
            return CreateInitialCourses();
        }

        try
        {
            var json = File.ReadAllText(_filePath);
            return JsonSerializer.Deserialize<List<Course>>(json) ?? CreateInitialCourses();
        }
        catch (JsonException)
        {
            return CreateInitialCourses();
        }
        catch (IOException)
        {
            return CreateInitialCourses();
        }
    }

    private static List<Course> CreateInitialCourses() =>
    [
        new Course { Title = "Основы C# и .NET", Description = "Изучаем базовый синтаксис", Author = "Иван Иванов" },
        new Course { Title = "Avalonia UI с нуля", Description = "Создание кроссплатформенных интерфейсов", Author = "Петр Петров" },
        new Course { Title = "Паттерн MVVM", Description = "Правильная архитектура приложений", Author = "Тимур Тельманович" },
        new Course { Title = "Веб-разработка на ASP.NET Core", Description = "Создание современных веб-приложений.", Author = "Алексей Смирнов" },
        new Course { Title = "Базы данных и EF Core", Description = "Подключение БД и работа с данными", Author = "Елена Кузнецова" },
        new Course { Title = "Асинхронность и многопоточность", Description = "Изучение async/await, Task в C#.", Author = "Дмитрий Волков" },
        new Course { Title = "Юнит-тестирование", Description = "Написание надежных тестов с помощью xUnit.", Author = "Юсуфов Расул" },
        new Course { Title = "Git и командная работа", Description = "Основы контроля версий и работа с GitHub.", Author = "Сергей Попов" }
    ];
}
