﻿using System;
using System.Collections.Generic;

namespace Cross_Platform_Course_Player.Models;

public class Course
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string Author { get; set; } = string.Empty;

    
    public string AuthorDisplay => $"Автор: {Author}";

    public List<Lesson> Lessons { get; set; } = new();
}