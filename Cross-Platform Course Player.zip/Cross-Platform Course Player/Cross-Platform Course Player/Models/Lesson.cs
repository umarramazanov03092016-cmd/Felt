﻿namespace Cross_Platform_Course_Player.Models;

public class Lesson
{
   
    
        public string Title { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public string VideoUrl { get; set; } = string.Empty;
        public int DurationMinutes { get; set; }
        public bool IsCompleted { get; set; }
    
}
