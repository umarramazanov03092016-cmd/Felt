using Avalonia.Controls;

namespace Cross_Platform_Course_Player.Views;

public partial class CourseDetailsView : UserControl
{
    public CourseDetailsView()
    {
        InitializeComponent();
    }
}
