using Avalonia.Controls;

namespace Cross_Platform_Course_Player.Views;

public partial class CatalogView : UserControl
{
    public CatalogView()
    {
        InitializeComponent();
    }
}