using Avalonia.Controls;

namespace Cross_Platform_Course_Player.Views;

public partial class ProfileView : UserControl
{
    public ProfileView()
    {
        InitializeComponent();
    }
}