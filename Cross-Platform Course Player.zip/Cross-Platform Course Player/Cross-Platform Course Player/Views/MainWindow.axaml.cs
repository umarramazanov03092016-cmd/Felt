﻿using Avalonia.Controls;

namespace Cross_Platform_Course_Player.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}