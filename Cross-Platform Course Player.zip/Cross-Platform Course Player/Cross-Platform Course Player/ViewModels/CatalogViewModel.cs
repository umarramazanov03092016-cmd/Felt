﻿using System.Collections.ObjectModel;
using System;
using Cross_Platform_Course_Player.Models;

namespace Cross_Platform_Course_Player.ViewModels;

public partial class CatalogViewModel : ViewModelBase
{
    private readonly Action<Course>? _openCourse;

    private Course? _selectedCourse;

    public Course? SelectedCourse
    {
        get => _selectedCourse;
        set
        {
            if (_selectedCourse == value)
            {
                return;
            }

            _selectedCourse = value;
            OnPropertyChanged();

            if (value is not null)
            {
                _openCourse?.Invoke(value);
            }
        }
    }

    public ObservableCollection<Course> Courses { get; }

    public CatalogViewModel(ObservableCollection<Course>? courses = null, Action<Course>? openCourse = null)
    {
        _openCourse = openCourse;
        Courses = courses ?? new ObservableCollection<Course>();
    }

}