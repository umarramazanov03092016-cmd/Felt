﻿using System.Windows.Input;
using Cross_Platform_Course_Player.Models;
using Cross_Platform_Course_Player.Services;

namespace Cross_Platform_Course_Player.ViewModels;

public class MainViewModel : ViewModelBase
{
    private readonly CourseRepository _courseRepository = new();
    private ViewModelBase _currentPage = null!;


    public ViewModelBase CurrentPage
    {
        get => _currentPage;
        set { _currentPage = value; OnPropertyChanged(); }
    }

   
    public ICommand OpenCatalogCommand { get; }
    public ICommand OpenProfileCommand { get; }
    public ICommand CreateCourseCommand { get; }

    public MainViewModel()
    {
        CurrentPage = CreateCatalogViewModel();

        OpenCatalogCommand = new RelayCommand(_ => OpenCatalog());
        OpenProfileCommand = new RelayCommand(_ => CurrentPage = new ProfileViewModel());
        CreateCourseCommand = new RelayCommand(_ => OpenCourseCreation());
    }

    private CatalogViewModel CreateCatalogViewModel() => new(_courseRepository.Courses, OpenCourse);

    private void OpenCourse(Course course)
    {
        CurrentPage = new CourseDetailsViewModel(course, OpenCatalog);
    }

    private void OpenCatalog()
    {
        CurrentPage = CreateCatalogViewModel();
    }

    private void OpenCourseCreation()
    {
        CurrentPage = new CourseCreationViewModel(_courseRepository.AddCourse, OpenCatalog);
    }
}