﻿namespace Cross_Platform_Course_Player.ViewModels;

public class ProfileViewModel : ViewModelBase
{
    private string _userName = "Студент";
    public string UserName
    {
        get => _userName;
        set { _userName = value; OnPropertyChanged(); }
    }

    private string _email = "student@example.com";
    public string Email
    {
        get => _email;
        set { _email = value; OnPropertyChanged(); }
    }
}