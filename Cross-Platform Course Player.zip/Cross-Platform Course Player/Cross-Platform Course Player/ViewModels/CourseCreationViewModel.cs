using System;
using Cross_Platform_Course_Player.Models;

namespace Cross_Platform_Course_Player.ViewModels;

public class CourseCreationViewModel : ViewModelBase
{
    private readonly Action<Course> _publishCourse;
    private readonly Action _cancel;
    private string _title = string.Empty;
    private string _description = string.Empty;
    private string _author = string.Empty;
    private string _lessonContent = string.Empty;
    private string _validationMessage = string.Empty;

    public string Title
    {
        get => _title;
        set { _title = value; OnPropertyChanged(); }
    }

    public string Description
    {
        get => _description;
        set { _description = value; OnPropertyChanged(); }
    }

    public string Author
    {
        get => _author;
        set { _author = value; OnPropertyChanged(); }
    }

    public string LessonContent
    {
        get => _lessonContent;
        set { _lessonContent = value; OnPropertyChanged(); }
    }

    public string ValidationMessage
    {
        get => _validationMessage;
        private set { _validationMessage = value; OnPropertyChanged(); }
    }

    public RelayCommand PublishCommand { get; }
    public RelayCommand CancelCommand { get; }

    public CourseCreationViewModel(Action<Course> publishCourse, Action cancel, string author = "")
    {
        _publishCourse = publishCourse;
        _cancel = cancel;
        Author = author;
        PublishCommand = new RelayCommand(_ => Publish());
        CancelCommand = new RelayCommand(_ => _cancel());
    }

    private void Publish()
    {
        if (string.IsNullOrWhiteSpace(Title) ||
            string.IsNullOrWhiteSpace(Description) ||
            string.IsNullOrWhiteSpace(Author) ||
            string.IsNullOrWhiteSpace(LessonContent))
        {
            ValidationMessage = "Заполните название, описание, имя автора и материал урока.";
            return;
        }

        var course = new Course
        {
            Title = Title.Trim(),
            Description = Description.Trim(),
            Author = Author.Trim(),
            Lessons =
            [
                new Lesson
                {
                    Title = "Материал курса",
                    Content = LessonContent.Trim()
                }
            ]
        };

        try
        {
            _publishCourse(course);
            _cancel();
        }
        catch (Exception)
        {
            ValidationMessage = "Не удалось сохранить курс. Проверьте доступ к папке данных приложения.";
        }
    }
}
