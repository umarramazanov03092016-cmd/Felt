using System;
using CommunityToolkit.Mvvm.Input;
using Cross_Platform_Course_Player.Models;

namespace Cross_Platform_Course_Player.ViewModels;

public partial class CourseDetailsViewModel : ViewModelBase
{
    private readonly Action _returnToCatalog;

    public Course Course { get; }

    public CourseDetailsViewModel(Course course, Action returnToCatalog)
    {
        Course = course;
        _returnToCatalog = returnToCatalog;
    }

    [RelayCommand]
    private void Back()
    {
        _returnToCatalog();
    }
}
